import pandas
import pandas as pd

data = pd.read_csv('./vendas.csv')
print(data)